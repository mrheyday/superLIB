#!/usr/bin/env bash
set -e
TARGET=$(git rev-parse --show-toplevel)
cp -r audit "$TARGET/"
echo "Audit package installed into repo."
