## Invariants
Determinism, atomicity, flash conservation.