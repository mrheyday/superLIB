## Non-Goals
No strategy optimization, no pricing.