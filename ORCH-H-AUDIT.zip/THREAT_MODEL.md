## Threat Model
MEV mutation, replay, flash-loan abuse.