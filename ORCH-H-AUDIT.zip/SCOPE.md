## Scope
Core ORCH-H protocol, executor, DFA, meta-tx adapter.