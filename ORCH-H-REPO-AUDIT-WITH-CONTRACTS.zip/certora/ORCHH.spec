// Replace with your full Certora ruleset.
